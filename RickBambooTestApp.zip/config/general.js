exports.config =
{
	run_as_cluster: true,
	winston_logging_level: "error"
};
